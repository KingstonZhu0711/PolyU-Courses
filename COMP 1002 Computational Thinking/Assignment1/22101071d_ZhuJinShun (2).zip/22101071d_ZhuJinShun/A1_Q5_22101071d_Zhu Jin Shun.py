#Name:Zhu Jin Shun
#Student ID:22101071D

import math
 
print("The programme is to calculate the root(s)of the quadratic equation,ax^2+bx+c=0")
a=eval(input("Please enter the value a."))
b=eval(input("Please enter the value b."))
c=eval(input("Please enter the value c."))
def findroots():
    
    d = b * b - 4 * a * c
    sqrtvalue=math.sqrt(abs(d))
    if d>0:
        print("There are two roots:",((-b + sqrtvalue)/(2 * a),(-b - sqrtvalue)/(2 * a)))

    elif d == 0:
        print("There is only one root:",(-b / (2*a)))
        
    else: 
        print("Invalid Input")
        
        
findroots()
         
        
    
