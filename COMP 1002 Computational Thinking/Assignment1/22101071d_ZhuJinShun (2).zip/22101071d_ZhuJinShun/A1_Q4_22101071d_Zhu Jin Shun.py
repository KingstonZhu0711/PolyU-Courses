#Student name:Zhu Jin Shun
#Student ID:22101071D
#Two examples
#input:300 output:454
#input:1000 output:1750


a=eval(input("Please enter a decimal number(an integer number in base 10)."))
N=[]
octalnumber= ' '

while a > 0:
    c = a % 8
    b = a//8
    print("quotient",b)
    print("remainder",c)
    a=b
    N.append(c)

N.reverse()
for B in N:
    octalnumber=octalnumber +str(B)
    
        
print("The octal number is", octalnumber)
