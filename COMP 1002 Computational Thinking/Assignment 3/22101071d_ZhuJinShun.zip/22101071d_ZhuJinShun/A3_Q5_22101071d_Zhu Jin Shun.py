#Student ID:22101071D
#Student Name:Zhu Jin Shun
#Question 5 Part A
X=[]
def myMedian(X):
    
    c=[] 
    while len(X)>0:
        length=len(X)
        x=0
        max2=X[x]
        while x <length:
            if X[x] > max2:
                max2=X[x]
            x=x+1
        c.append(max2)
        X.remove(max2)
    n=len(c)
    if n % 2 == 0:
        median1 = c[n//2]
        median2 = c[n//2 - 1]
        median = (median1 + median2)/2
    else:
        median = c[n//2]
    return median


#Question 5 Part B
infile = open("iris2021.csv", "r")
data = infile.readlines()
a=[]
b=[]
c=[]
for word in data:
    word1=list(word[:-1].split(","))
    if word1[1]=="setosa":
        c.append(eval(word1[0]))
    elif word1[1]=="versicolor":
        b.append(eval(word1[0]))
    elif word1[1]=="virginica":
        a.append(eval(word1[0]))
    else:
        continue

a=myMedian(a)
b=myMedian(b)
c=myMedian(c)

print("The median of Petal.Width for virginica is",f"{a:0.3f}")
print("The median of Petal.Width for versicolor is",f"{b:0.3f}")
print("The median of Petal.Width for setosa is",f"{c:0.3f}")

    
