#Student ID:22101071d
#Name: Zhu Jin Shun

def myIntersection(A,B):
   """Input a tuple or a list in function and find the same intersection
items"""
   c=[]
   for i in A:
      for j in B:
         if i==j:
            c+=[i]
   c=set(c)
   c=list(c)
   return c

def main():
   A=list(eval(input("Please enter a list or tuple of different numbers separated by ',':")))
   B=list(eval(input("Please enter a list or tuple of different numbers separated by ',':")))
   print("A=",A)
   print("B=",B)
   result=myIntersection(A,B)
   print("The intersection of A and B is",result)
main()
